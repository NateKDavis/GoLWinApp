﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoLWinApp
{
    public class Cell
    {
        public bool isAlive = false;
    }
}
