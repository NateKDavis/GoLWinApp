﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GOLStartUpTemplate1
{
    public class Cell
    {
        public bool isAlive = false;
    }
}
